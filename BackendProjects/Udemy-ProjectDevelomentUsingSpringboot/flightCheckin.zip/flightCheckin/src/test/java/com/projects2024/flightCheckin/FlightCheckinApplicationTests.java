package com.projects2024.flightCheckin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightCheckinApplicationTests {

	@Test
	void contextLoads() {
	}

}
