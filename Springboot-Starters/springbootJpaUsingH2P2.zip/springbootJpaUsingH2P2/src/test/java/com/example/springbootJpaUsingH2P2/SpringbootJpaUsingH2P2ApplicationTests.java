package com.example.springbootJpaUsingH2P2;

import com.example.springbootJpaUsingH2P2.DAO.StudentDao;
import com.example.springbootJpaUsingH2P2.Model.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class SpringbootJpaUsingH2P2ApplicationTests {

	@Autowired
	StudentDao studentDao;

	@Test
	void testSaveStudent() {
		Student student = new Student();
		student.setId(1);
		student.setName("Yamy");
		student.setTestScores(10.5);
		Student s = studentDao.save(student);

		assertNotNull(s);
		assertEquals("Yamy",s.getName());

	}

}
