package com.example.springbootJpaUsingH2P2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJpaUsingH2P2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJpaUsingH2P2Application.class, args);
	}

}
