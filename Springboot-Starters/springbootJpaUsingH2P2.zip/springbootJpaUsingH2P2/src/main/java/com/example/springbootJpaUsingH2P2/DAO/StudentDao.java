package com.example.springbootJpaUsingH2P2.DAO;

import com.example.springbootJpaUsingH2P2.Model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentDao extends JpaRepository<Student,Integer> {
}
