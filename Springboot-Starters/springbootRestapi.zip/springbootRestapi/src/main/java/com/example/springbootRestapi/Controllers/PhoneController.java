package com.example.springbootRestapi.Controllers;

import com.example.springbootRestapi.DAO.PhoneDAO;
import com.example.springbootRestapi.Model.Phone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class PhoneController {

    @Autowired
    PhoneDAO phoneDAO;

    private static final Logger LOGGER = LoggerFactory.getLogger(PhoneController.class);

    @RequestMapping(value = "/phones", method = RequestMethod.GET)
    @Cacheable("phone-cache")
    @Transactional(readOnly = true)
    public List<Phone> findAllRecords(){
//        System.out.println(phoneDAO);
        LOGGER.info("getting infoooo xxxxx" + phoneDAO);
        return phoneDAO.findAll();
    }

    @RequestMapping(value = "/phone/{id}",method = RequestMethod.GET)
    public Optional<Phone> findOneRecord(@PathVariable("id") int id){
        return phoneDAO.findById(id);
    }

    @RequestMapping(value = "/phones", method = RequestMethod.POST)
    public Phone saveRecord(@RequestBody Phone phone){
        return phoneDAO.save(phone);
    }

    @RequestMapping(value = "/phones" , method = RequestMethod.PUT)
    public Phone updateRecord(@RequestBody Phone phone){
        return phoneDAO.save(phone);
    }

//    @RequestMapping(value = "/phones", method = RequestMethod.PATCH)
//    public Phone updatePatchRecord(@RequestBody Phone phone){
//        return phoneDAO.save(phone.getName());
//    }

    //@CacheEvict("phone-cache") - for a delete method
}
