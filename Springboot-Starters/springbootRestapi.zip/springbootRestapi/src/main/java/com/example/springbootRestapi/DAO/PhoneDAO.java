package com.example.springbootRestapi.DAO;

import com.example.springbootRestapi.Model.Phone;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PhoneDAO extends JpaRepository<Phone,Integer> {
}
