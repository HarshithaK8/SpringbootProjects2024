package com.example.springbootRestapi;

import com.example.springbootRestapi.Model.Phone;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class SpringbootRestapiApplicationTests {

	//profile
	@Value("${spring.restapi.url}")
	String baseUrl;

	@Test
	void testGetPhone() {
		System.out.println(baseUrl);
		RestTemplate restTemplate = new RestTemplate();
		Phone phone = restTemplate.getForObject(baseUrl+"/2", Phone.class);
		assertNotNull(phone);
		assertEquals("Samsung", phone.getName());
	}

}
