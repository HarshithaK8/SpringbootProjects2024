package com.example.springbootDIP1.Service;

import com.example.springbootDIP1.Dao.PaymentDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentServicempl {

    @Autowired
    PaymentDAO paymentDAO;

    public PaymentDAO getPaymentDAO() {
        return paymentDAO;
    }

    public void setPaymentDAO(PaymentDAO paymentDAO) {
        this.paymentDAO = paymentDAO;
    }

    public int sum(int a, int b){
        return a+b;
    }
}
