package com.example.springbootDIP1.Service;

public interface PaymentService {
}
