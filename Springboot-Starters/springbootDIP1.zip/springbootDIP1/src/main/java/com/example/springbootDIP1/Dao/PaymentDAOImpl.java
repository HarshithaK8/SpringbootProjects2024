package com.example.springbootDIP1.Dao;

import org.springframework.stereotype.Repository;

@Repository
public class PaymentDAOImpl implements PaymentDAO{
}
