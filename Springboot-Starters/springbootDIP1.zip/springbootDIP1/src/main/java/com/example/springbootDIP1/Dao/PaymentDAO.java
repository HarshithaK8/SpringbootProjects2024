package com.example.springbootDIP1.Dao;

public interface PaymentDAO {

}
