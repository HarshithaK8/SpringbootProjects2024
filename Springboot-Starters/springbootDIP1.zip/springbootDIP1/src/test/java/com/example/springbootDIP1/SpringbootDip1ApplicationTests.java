package com.example.springbootDIP1;

import com.example.springbootDIP1.Service.PaymentServicempl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class SpringbootDip1ApplicationTests {

	@Autowired
	PaymentServicempl servicempl;

	@Test
	void testDI() {
		assertNotNull(servicempl.getPaymentDAO());
		assertEquals(5,servicempl.sum(2,3));
	}

}
